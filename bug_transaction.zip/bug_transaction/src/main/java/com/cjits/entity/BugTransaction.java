
package com.cjits.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name="transactions")
public class BugTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    private String bugWorkDesc;

    @Column(name = "bug_id")
    private Long bugId; // Foreign key to Bug entity

    private String bugExplanation;

    @Temporal(TemporalType.DATE)
    private Date workDate;

    // Default constructor required by JPA
    public BugTransaction() {
    }

    // Getters and setters

    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public String getBugWorkDesc() {
        return bugWorkDesc;
    }

    public void setBugWorkDesc(String bugWorkDesc) {
        this.bugWorkDesc = bugWorkDesc;
    }

    public Long getBugId() {
        return bugId;
    }

    public void setBugId(Long bugId) {
        this.bugId = bugId;
    }

    public String getBugExplanation() {
        return bugExplanation;
    }

    public void setBugExplanation(String bugExplanation) {
        this.bugExplanation = bugExplanation;
    }

    public Date getWorkDate() {
        return workDate;
    }

    public void setWorkDate(Date workDate) {
        this.workDate = workDate;
    }

    // Omitted for brevity

    @Override
    public String toString() {
        return "BugTransaction{" +
                "transactionId=" + transactionId +
                ", bugWorkDesc='" + bugWorkDesc + '\'' +
                ", bugId=" + bugId +
                ", bugExplanation='" + bugExplanation + '\'' +
                ", workDate=" + workDate +
                '}';
    }
}