package com.cjits.entity;
import jakarta.persistence.*;
@Entity
@Table(name = "project")
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    //private  int projectid;
    @Column(name = "proj_id")
    private int projectId;

    @Column(name = "proj_name")
    private String projectName;
//    private long id;

    public Project() {
    }



    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
    @Override
    public String toString() {
        return  projectId+", "+projectName ;
    }





}