package com.cjits.service;

import com.cjits.entity.BugTransaction;
import com.cjits.repository.BugTransactionRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BugTransactionServiceImpl implements BugTransactionService {

    @Autowired
    private BugTransactionRepository bugTransactionRepository;

    @Override
    public List<BugTransaction> getAllBugTransactions() {
        return bugTransactionRepository.findAll();
    }

    @Override
    public BugTransaction getBugTransactionById(Long id) {
        Optional<BugTransaction> bugTransaction = bugTransactionRepository.findById(id);
        return bugTransaction.orElse(getAllBugTransaction());
    }

    private BugTransaction getAllBugTransaction() {
        return (BugTransaction) bugTransactionRepository.findAll();
    }

    @Override
    public BugTransaction createBugTransaction(BugTransaction bugTransaction) {
        try {
            return bugTransactionRepository.save(bugTransaction);
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Handle exception appropriately, perhaps return a proper error response
        }
    }

    @Override
    public BugTransaction updateBugTransaction(Long id, BugTransaction updatedBugTransaction) {
        Optional<BugTransaction> optionalExistingBugTransaction = bugTransactionRepository.findById(id);
        if (optionalExistingBugTransaction.isPresent()) {
            BugTransaction existingBugTransaction = optionalExistingBugTransaction.get();
            BeanUtils.copyProperties(updatedBugTransaction, existingBugTransaction, "transactionId");
            return bugTransactionRepository.save(existingBugTransaction);
        } else {
            return null; // or throw an exception if required
        }
    }

    @Override
    public void deleteBugTransaction(Long id) {
        bugTransactionRepository.deleteById(id);
    }
}