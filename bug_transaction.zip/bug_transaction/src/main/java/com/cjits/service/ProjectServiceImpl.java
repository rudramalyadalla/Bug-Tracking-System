package com.cjits.service;



import com.cjits.entity.Project;

import com.cjits.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProjectServiceImpl implements ProjectService {
    @Autowired
    private ProjectRepository repo;
    @Override
    public Project saveProject(Project p) {
        return repo.save(p);

    }

    @Override
    public List<Project> getAllProjects() {
        try {
            return repo.findAll();
        } catch (Exception e) {
            // Log the exception or handle it as appropriate
            e.printStackTrace();
            // You can throw a custom exception here if needed
            throw new RuntimeException("An error occurred while fetching projects", e);
        }
    }


    @Override
    public Project findProjectById(Long id) throws RuntimeException {
        Optional<Project> project = repo.findById(id);
        if(project.isPresent()) {
            return project.get();
        }else
        {
            throw new RuntimeException("Entered id:"+id+"Not found in repositories");
        }
    }


    @Override
    public Project updateProject(Project p, long id) throws RuntimeException {
        Project project = repo.findById(id).get();
        if(project.getProjectId()!=0) {

            project.setProjectName(p.getProjectName());

        }
        else
        {
            throw new RuntimeException("Entered product id:"+id+" Not found");
        }
        repo.save(project);
        return project;
    }

    @Override
    public void deleteProject(Long id) {
        repo.deleteById(id);

    }
}