package com.cjits.service;

import com.cjits.entity.Bug;
import com.cjits.repository.BugRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class BugServiceImpl implements BugService {

    @Autowired
    private BugRepository bugRepository;

    @Override
    public List<Bug> getAllBugs() {
        return bugRepository.findAll();
    }

    @Override
    public Bug getBugById(Long id) {
        return bugRepository.findById(id).orElse(null);
    }

    @Override
    public Bug createBug(Bug bug) {
        // Set start date to current date
        bug.setStartDate(new Date());
        // Ensure end date is null
        bug.setEndDate(null);
        return bugRepository.save(bug);
    }

    @Override
    public Bug updateBug(Long id, Bug bug) {
        if (bugRepository.existsById(id)) {
            bug.setId(id);
            return bugRepository.save(bug);
        }
        return null;
    }

    @Override
    public void deleteBug(Long id) {
        bugRepository.deleteById(id);
    }
}