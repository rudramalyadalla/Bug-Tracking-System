package com.cjits.service;
import com.cjits.entity.Bug;

import java.util.List;
public interface BugService {

    List<Bug> getAllBugs();
    Bug getBugById(Long id);
    Bug createBug(Bug bug);
    Bug updateBug(Long id, Bug bug);
    void deleteBug(Long id);
}
