package com.cjits.service;



import com.cjits.entity.Project;

import java.util.List;

public interface ProjectService {



    public Project saveProject(Project p) throws RuntimeException;
    public List<Project> getAllProjects() throws  RuntimeException;
    public Project findProjectById(Long id) throws RuntimeException;



    public Project updateProject(Project p, long id) throws RuntimeException;



    public void deleteProject(Long id);
}