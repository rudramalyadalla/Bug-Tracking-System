package com.cjits.service;

import com.cjits.entity.BugTransaction;
import java.util.List;

public interface BugTransactionService {
    List<BugTransaction> getAllBugTransactions();
    BugTransaction getBugTransactionById(Long id);
    BugTransaction createBugTransaction(BugTransaction bugTransaction);
    BugTransaction updateBugTransaction(Long id, BugTransaction updatedBugTransaction);
    void deleteBugTransaction(Long id);
}