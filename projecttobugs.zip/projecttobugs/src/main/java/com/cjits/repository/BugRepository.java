package com.cjits.repository;

import com.cjits.entity.Bug;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BugRepository extends JpaRepository<Bug, Long> {
    // Define custom query methods if needed
}