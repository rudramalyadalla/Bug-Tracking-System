package com.cjits.service;

import com.cjits.entity.Bug;
import com.cjits.repository.BugRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class BugServiceImpl implements BugService {

    @Autowired
    private BugRepository bugRepository;

    @Override
    public List<Bug> getAllBugs() {
        return bugRepository.findAll();
    }

    @Override
    public Bug getBugById(Long id) {
        return bugRepository.findById(id).orElse(null);
    }

    @Override
    public Bug addBug(Bug bug) {
        return bugRepository.save(bug);
    }

    @Override
    public Bug updateBug(Long id, Bug bug) {
        Bug existingBug = getBugById(id);
        if (existingBug != null) {
            bug.setBugId(id);
            return bugRepository.save(bug);
        }
        return null;
    }

    @Override
    public boolean deleteBug(Long id) {
        if (bugRepository.existsById(id)) {
            bugRepository.deleteById(id);
            return true;
        }
        return false;
    }

//    @Override
//    public List<Bug> getBugsByCreatedBy(String createdBy) {
//        return bugRepository.findByCreatedBy(createdBy);
//    }
//
//    @Override
//    public List<Bug> getBugsByProjectId(Long projectId) {
//        return bugRepository.findByProjectId(projectId);
//    }
//
//    @Override
//    public List<Bug> getBugsByDateRange(Date startDate, Date endDate) {
//        return bugRepository.findByStartDateBetween(startDate, endDate);
//    }
//
//    @Override
//    public List<Bug> getBugsByDescriptionContaining(String keyword) {
//        return bugRepository.findByDescriptionContaining(keyword);
//    }

    // You can add additional methods as needed

}