package com.cjits.service;

import com.cjits.entity.Bug;

import java.util.Date;
import java.util.List;

public interface BugService {

    List<Bug> getAllBugs();
    Bug getBugById(Long id);
    Bug addBug(Bug bug);
    Bug updateBug(Long id, Bug bug);
    boolean deleteBug(Long id);

    // You can add additional methods as needed
//    List<Bug> getBugsByCreatedBy(String createdBy);
//    List<Bug> getBugsByProjectId(Long projectId);
//    List<Bug> getBugsByDateRange(Date startDate, Date endDate);
//    List<Bug> getBugsByDescriptionContaining(String keyword);
}