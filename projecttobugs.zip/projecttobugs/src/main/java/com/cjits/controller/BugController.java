package com.cjits.controller;

import com.cjits.entity.Bug;
import com.cjits.service.BugService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/restapi/bugs")
public class BugController {

    @Autowired
    private BugService bugService;

    @GetMapping
    public List<Bug> getAllBugs() {
        return bugService.getAllBugs();
    }

    @GetMapping("/{id}")
    public Bug getBugById(@PathVariable Long id) {
        return bugService.getBugById(id);
    }

    @PostMapping
    public Bug addBug(@RequestBody Bug bug) {
        return bugService.addBug(bug);
    }

    @PutMapping("/{id}")
    public Bug updateBug(@PathVariable Long id, @RequestBody Bug bug) {
        return bugService.updateBug(id, bug);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBug(@PathVariable Long id) {
        boolean deleted = bugService.deleteBug(id);
        if (deleted) {
            return new ResponseEntity<>("Deleted bug with id: " + id, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Bug not found with id: " + id, HttpStatus.NOT_FOUND);
        }
    }
}