package com.cjits.controller;

import com.cjits.entity.Project;
import com.cjits.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.logging.Logger;

@RestController
@RequestMapping("/restapi/projects")
public class ProjectController {
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Autowired
    private ProjectService service;

    // Create REST API
    @PostMapping
    public ResponseEntity<Project> saveProject(@RequestBody Project project) {
        logger.warning("printing : " + project);
        try {
            Project savedProject = service.saveProject(project);
            return new ResponseEntity<>(savedProject, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Get REST API
    @GetMapping
    public ResponseEntity<List<Project>> getAllProjects() {
        try {
            List<Project> projects = service.getAllProjects();
            return new ResponseEntity<>(projects, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Get REST API by Id
    @GetMapping("{id}")
    public ResponseEntity<Object> getProjectById(@PathVariable("id") Long projectId) {
        try {
            Project project = service.findProjectById(projectId);
            if (project != null) {
                return ResponseEntity.ok().body(project);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to retrieve project: " + e.getMessage());
        }
    }



    // Update REST API
    @PutMapping("{id}")
    public ResponseEntity<Object> updateProject(@RequestBody Project project, @PathVariable("id") long projectId) {
        try {
            Project updatedProject = service.updateProject(project, projectId);
            if (updatedProject != null) {
                return ResponseEntity.ok().body("Project updated successfully");
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update project: " + e.getMessage());
        }
    }


    // Delete REST API
    // Delete Project REST API
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable("id") long projectId) {
        try {
            service.deleteProject(projectId);
            return new ResponseEntity<>("Deleted", HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found for ID: " + projectId);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}